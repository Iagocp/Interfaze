let x=250;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  for(var i=0;i<=400;i=i+20){
    for(var j=0;j<=400;j=j+20){
      
    
    //console.log("i",i);
    circle(i,j,20);
  }
  }
}