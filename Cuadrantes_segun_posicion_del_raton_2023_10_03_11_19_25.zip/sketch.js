function setup() {
  createCanvas(windowWidth, windowHeight);
  textSize(36);
}

function draw() {
  // Limpiar pantalla
  background(0);

  // Dibujar cuadrados y texto
  if (mouseX < windowWidth / 2 && mouseY < windowHeight / 2) {
    fill(255, 0, 0);
    rect(0, 0, windowWidth / 2, windowHeight / 2);
    fill(0);
    text("arriba izquierda", mouseX, mouseY);
  } else if (mouseX >= windowWidth / 2 && mouseY < windowHeight / 2) {
    fill(0, 255, 0);
    rect(windowWidth / 2, 0, windowWidth / 2, windowHeight / 2);
    fill(0);
    text("arriba derecha", mouseX, mouseY);
  } else if (mouseX < windowWidth / 2 && mouseY >= windowHeight / 2) {
    fill(0, 0, 255);
    rect(0, windowHeight / 2, windowWidth / 2, windowHeight / 2);
    fill(0);
    text("abajo izquierda", mouseX, mouseY);
  } else {
    fill(255);
    rect(windowWidth / 2, windowHeight / 2, windowWidth / 2, windowHeight / 2);
    fill(0);
    text("abajo derecha", mouseX, mouseY);
  }
}