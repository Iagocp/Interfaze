//priemra variable desde donde empieza el primer ciruclo
let x=0;
//segunda variable desde donde empieza el segunda ciruclo
let y=0;

function setup() {
  createCanvas(400, 400);
  frameRate(15);
}


function draw() {
  background(220);
  
  //primer circulo
  
  fill(200,200,200);//Seleccion de color
  circle(x,200,50);
  x+=2.5;
  
  //segundo circulo
  fill(100,150,200);//Seleccion de color
  circle(y,300,50);
  y+=5;
  
  if(x>=550){
    x=0;
  }
    if(y>=550){
    y=0;
  }
  
  
  //dice la posicion del primer circulo
  console.log("primer circulo",x);
  //dice la posicion del segundo circulo
  console.log("segundo circulo",y);
}