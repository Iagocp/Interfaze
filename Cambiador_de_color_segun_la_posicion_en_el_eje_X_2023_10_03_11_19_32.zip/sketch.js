// Cogemos el ancho de la pnatalla
const windowWidth = window.innerWidth;

// La dividimos en tres
const sectionWidth = windowWidth / 4;

//Hacemos un evento que detecte la pos del raton
window.addEventListener('mousemove', (event) => {
  // Declaramos el raton
  const mouseX = event.clientX;

  //
  if (mouseX < sectionWidth) {
    document.body.style.backgroundColor = 'red';
  } else if (mouseX < sectionWidth * 2) {
    document.body.style.backgroundColor = 'green';
  } else {
    document.body.style.backgroundColor = 'blue';
  
}});